# Generate libs

```
npm install --no-optional
npm run build
```
