Build (will create a bundle and copy it to /tmp/stellar-util.js):

    npm install
    npm run build
